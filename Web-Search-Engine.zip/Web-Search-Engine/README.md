# ACC-Search-Engine
Web Search Engine


Web search engine project for Advanced Computing Concepts course

Technology used:Java, Jsoup library, Web crawler, HTML parser, HashMap, Inverted Indexing

Description: A web search engine developed to find HTML pages, parse the HTML content, convert them into text files and further search for keywords entered by user and find them into saved files.
The program will return the pages and respective ranking, if the keyowrd will be found. Otherwise, will suggest similar words
